package com.agencia.viagem.securityconfig;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

public class WebSecurityConfigurerAdapter {

	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
