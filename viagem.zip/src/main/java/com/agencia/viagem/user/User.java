package com.agencia.viagem.user;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Set;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;

    @ElementCollection(fetch = FetchType.EAGER)
    private Set<String> roles;

	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getRoles() {
		// TODO Auto-generated method stub
		return null;
	}
	

	public String getPassword1() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getUsername1() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getUsername11() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getters e Setters
}