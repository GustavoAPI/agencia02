package com.agencia.viagem.service;

import com.agencia.viagem.model.Destino;
import com.agencia.viagem.repository.DestinoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DestinoService {
    @Autowired
    private DestinoRepository destinoRepository;

    public Destino cadastrarDestino(Destino destino) {
        return destinoRepository.save(destino);
    }

    public List<Destino> listarDestinos() {
        return destinoRepository.findAll();
    }

    public List<Destino> pesquisarDestinos(String nome, String localizacao) {
        return destinoRepository.findByNomeContainingOrLocalizacaoContaining(nome, localizacao);
    }

    public Optional<Destino> obterDestinoPorId(Long id) {
        return destinoRepository.findById(id);
    }

    public void avaliarDestino(Long id, int nota) {
        Optional<Destino> destino = destinoRepository.findById(id);
        if (destino.isPresent()) {
            Destino d = destino.get();
            d.setNumeroAvaliacoes(d.getNumeroAvaliacoes() + 1);
            d.setAvaliacao(((d.getAvaliacao() * (d .getNumeroAvaliacoes() - 1)) + nota) / d.getNumeroAvaliacoes());
            destinoRepository.save(d);
        }
    }

    public void excluirDestino(Long id) {
        destinoRepository.deleteById(id);
    }
}