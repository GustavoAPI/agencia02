package com.agencia.viagem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenciaViagemApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgenciaViagemApplication.class, args);
    }
}